# 🤖 Personal Finance Advisor Bot

A production-ready full-stack Flask API template configured specifically for deployment on **Render**.

## 🚀 Render Deployment Instructions

1. **Create your Repo**: Extract this `.zip` file into a clean folder, initialize a local git repository, commit the files, and push them to a new **GitHub repository**.
2. **Deploy on Render**:
   - Log into your [Render Dashboard](https://dashboard.render.com).
   - Click **New +** and select **Web Service**.
   - Connect your GitHub repository.
3. **Configure Settings**:
   - **Environment / Runtime**: `Python`
   - **Build Command**: `pip install -r requirements.txt && flask db upgrade` (Note: Run `flask db init` and `flask db migrate` locally if deploying a relational system, or stick to SQLite for testing).
   - **Start Command**: `gunicorn wsgi:app`
4. **Environment Variables**:
   - Under the **Environment** tab on Render, add:
     - `SECRET_KEY` = your-random-secret-key
     - `OPENAI_API_KEY` = your-actual-openai-token