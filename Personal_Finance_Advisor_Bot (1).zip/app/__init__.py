from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from config import Config

db = SQLAlchemy()
migrate = Migrate()

def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    db.init_app(app)
    migrate.init_app(app, db)

    # Register blueprints
    from app.routes.auth import auth_bp
    from app.routes.tracking import tracking_bp
    from app.routes.advisor import advisor_bp

    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(tracking_bp, url_prefix='/api/tracking')
    app.register_blueprint(advisor_bp, url_prefix='/api/advisor')

    @app.route('/')
    def index():
        return {
            "status": "online",
            "message": "Welcome to the Personal Finance Advisor Bot API. Ready for Render deployment!"
        }

    return app