from flask import Blueprint, request, jsonify
from app.models import User, Income, Expense
from app.services.ai_engine import generate_budget_advice

advisor_bp = Blueprint('advisor', __name__)

@advisor_bp.route('/insights/<int:user_id>', methods=['GET'])
def get_insights(user_id):
    user = User.query.get_or_404(user_id)
    incomes = Income.query.filter_by(user_id=user_id).all()
    expenses = Expense.query.filter_by(user_id=user_id).all()
    
    # Structure data for the AI engine
    profile_data = {
        "username": user.username,
        "total_income": sum(i.amount for i in incomes),
        "expenses_by_category": {}
    }
    for e in expenses:
        profile_data["expenses_by_category"][e.category] = profile_data["expenses_by_category"].get(e.category, 0) + e.amount
        
    advice = generate_budget_advice(profile_data)
    return jsonify({"user": user.username, "ai_analysis": advice})