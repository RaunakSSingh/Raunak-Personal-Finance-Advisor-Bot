from flask import Blueprint, request, jsonify
from app import db
from app.models import Income, Expense

tracking_bp = Blueprint('tracking', __name__)

@tracking_bp.route('/expense', methods=['POST'])
def add_expense():
    data = request.get_json() or {}
    user_id = data.get('user_id') # Simplified for boilerplate (use tokens in production)
    if not user_id or 'amount' not in data or 'category' not in data:
        return jsonify({"error": "Missing expense details"}), 400
        
    expense = Expense(user_id=user_id, amount=data['amount'], category=data['category'], description=data.get('description', ''))
    db.session.add(expense)
    db.session.commit()
    return jsonify({"message": "Expense logged successfully"}), 201