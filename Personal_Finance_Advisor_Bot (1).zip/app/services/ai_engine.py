import os
from openai import OpenAI

def generate_budget_advice(profile_data):
    api_key = os.environ.get('OPENAI_API_KEY')
    if not api_key:
        return "AI analysis offline: Please configure your OPENAI_API_KEY environment variable on Render."
        
    try:
        client = OpenAI(api_key=api_key)
        prompt = f"""
        Analyze the following financial ledger overview and generate tailored budget recommendations, 
        highlight saving capacities, and suggest practical strategies:
        
        User Profile: {profile_data['username']}
        Total Logged Income: ${profile_data['total_income']}
        Breakdown of Expenses: {profile_data['expenses_by_category']}
        """
        
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are an expert full-stack Personal Finance Advisor Bot designed to evaluate flexible or rigid user income profiles and output strategic saving insights."},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message.content
    except Exception as e:
        return f"Error connecting to AI service: {str(e)}"